document.addEventListener('DOMContentLoaded', function () {
    const addNoteBtn = document.getElementById('add-note-btn');
    const noteModal = document.getElementById('note-modal');
    const closeBtn = document.querySelector('.close-btn');
    const saveNoteBtn = document.getElementById('save-note-btn');
    const notesContainer = document.getElementById('notes');
    const tagsContainer = document.querySelector('.tags');

    addNoteBtn.addEventListener('click', function () {
        noteModal.style.display = 'block';
    });

    closeBtn.addEventListener('click', function () {
        noteModal.style.display = 'none';
    });

    window.onclick = function (event) {
        if (event.target == noteModal) {
            noteModal.style.display = 'none';
        }
    };

    saveNoteBtn.addEventListener('click', function () {
        const title = document.getElementById('note-title').value;
        const content = document.getElementById('note-content').value;
        let tags = document.getElementById('note-tags').value;

        if (title && content) {
            tags = tags.split(',').map(tag => tag.trim().replace(/^#/, ''));

            const note = {
                id: Date.now(),
                title,
                content,
                tags
            };

            saveNoteToLocalStorage(note);
            noteModal.style.display = 'none';
            clearModalFields();
            displayNotes();
            displayTags();
        }
    });

    function clearModalFields() {
        document.getElementById('note-title').value = '';
        document.getElementById('note-content').value = '';
        document.getElementById('note-tags').value = '';
    }

    function saveNoteToLocalStorage(note) {
        let notes = JSON.parse(localStorage.getItem('notes')) || [];
        notes.push(note);
        localStorage.setItem('notes', JSON.stringify(notes));
    }

    function getNotesFromLocalStorage() {
        return JSON.parse(localStorage.getItem('notes')) || [];
    }

    function displayNotes() {
        const notes = getNotesFromLocalStorage();
        notesContainer.innerHTML = '';
        const noteCountElement = document.getElementById('note-count');
        const pinnedNotesContainer = document.getElementById('pinned-notes'); // Yeni ekledik

        const noteCount = notes.length;
        noteCountElement.innerText = `/${noteCount}`;

        notes.forEach(note => {
            const tags = Array.isArray(note.tags) ? note.tags.join(', ') : '';
            const noteElement = document.createElement('div');
            noteElement.classList.add('note');
            noteElement.innerHTML = `
            <div class="note-header">
                <h2>${note.title}</h2>
                <div class="note-header-btns">
                    <button onclick="deleteNote(${note.id})">
                        <i class="fa-light fa-trash"></i>
                    </button>
                    <button onclick="pinNote(${note.id})">
                        <i class="fa-light fa-thumbtack"></i>
                    </button>
                </div>
            </div>
                <p>${note.content}</p>
                <p id="note-tag">Tags: ${tags}</p>
                
            `;
            if (note.pinned) { // Eğer not pinlenmişse
                const pinnedNoteElement = document.createElement('div');
                pinnedNoteElement.classList.add('pinned-note');
                pinnedNoteElement.innerHTML = `
                    <h2>${note.title}</h2>
                    <p>${note.content}</p>
                    <p>Tags: ${tags}</p>
                    <button onclick="deleteNote(${note.id})"><i class="fa-regular fa-trash"></i></button>
                    <button onclick="unpinNote(${note.id})">Unpin</button>
                `;
                pinnedNotesContainer.appendChild(pinnedNoteElement);
            } else {
                notesContainer.appendChild(noteElement);
            }
        });
    }

    window.deleteNote = function (id) {
        let notes = getNotesFromLocalStorage();
        notes = notes.filter(note => note.id !== id);
        localStorage.setItem('notes', JSON.stringify(notes));
        displayNotes();
        displayTags();
    };

    window.filterNotes = function (tag) {
        const notes = getNotesFromLocalStorage();
        notesContainer.innerHTML = '';

        notes.filter(note => Array.isArray(note.tags) && note.tags.includes(tag)).forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.classList.add('note');
            noteElement.innerHTML = `
                <h2>${note.title}</h2>
                <p>${note.content}</p>
                <p>Tags: ${note.tags.join(', ')}</p>
                <button onclick="deleteNote(${note.id})"><i class="fa-regular fa-trash"></i></button>
            `;
            notesContainer.appendChild(noteElement);
        });
    };

    function displayTags() {
        const notes = getNotesFromLocalStorage();
        const tagCounts = {};
        notes.forEach(note => {
            if (Array.isArray(note.tags)) {
                note.tags.forEach(tag => {
                    if (tagCounts[tag]) {
                        tagCounts[tag]++;
                    } else {
                        tagCounts[tag] = 1;
                    }
                });
            }
        });

        const sortedTags = Object.keys(tagCounts).sort((a, b) => tagCounts[b] - tagCounts[a]);
        tagsContainer.innerHTML = '';

        const defaultTags = ['personal', 'work', 'home'];

        if (sortedTags.length === 0) {
            defaultTags.forEach(tag => {
                const button = document.createElement('button');
                button.classList.add('tag');
                button.innerText = `#${tag}`;
                button.setAttribute('onclick', `filterNotes('${tag}')`);
                tagsContainer.appendChild(button);
            });
        } else {
            const tagsToShow = sortedTags.slice(0, 3);
            while (tagsToShow.length < 3) {
                const tagToAdd = defaultTags.find(tag => !tagsToShow.includes(tag));
                if (tagToAdd) tagsToShow.push(tagToAdd);
            }

            tagsToShow.forEach(tag => {
                const button = document.createElement('button');
                button.classList.add('tag');
                button.innerText = `#${tag}`;
                button.setAttribute('onclick', `filterNotes('${tag}')`);
                tagsContainer.appendChild(button);
            });
        }
    }

    displayNotes();
    displayTags();
});